let leftbtn =document.querySelector(".btn-r");
let rightbtn =document.querySelector(".btn-l");
let slider = document.querySelector("slider-sec")

rightbtn.addEventListener('click',function(event){
    let c =document.querySelector(".product-slide");
    c.scrollLeft += 1100;
    event.preventDefault();
})
leftbtn.addEventListener('click',function(event){
    let c =document.querySelector(".product-slide");
    c.scrollLeft -= 1100;
    event.preventDefault();
})

document.addEventListener('DOMContentLoaded', function () {
    // Selecting DOM elements
    const loginBtn = document.querySelector('.login-btn');
    const loginForm = document.querySelector('.login-form');
    const backArrow = document.querySelector('.fa-arrow-left');

    // Adding event listener for loginBtn click
    loginBtn.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent default form submission
        // Toggle the display of loginForm
        if (loginForm.style.display === 'none' || loginForm.style.display === '') {
            loginForm.style.display = 'block';
        } else {
            loginForm.style.display = 'none';
        }
    });

    // Adding event listener for backArrow click
    backArrow.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent default link behavior
        loginForm.style.display = 'none'; // Hide loginForm
    });
});



