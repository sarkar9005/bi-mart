from django.contrib import admin
from .models import Product, Heading, Category, Subcategory, SpeacialHeadingProduct, SpecialHeadng, Brand, Customer, Cart, Order, UserAddressBook, PincodeAvailable, Payment

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'id', 'desc',  'price', 'offer_percent', 'image1', 'image2', 'image3', 'image4', 'image5', 'que', 'subcategory']

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ["category_name"]

@admin.register(Subcategory)
class SubcategoryAdmin(admin.ModelAdmin):
    list_display = ['sub_category_name']

@admin.register(Brand)
class BrandAdmin(admin.ModelAdmin):
    list_display = ['name']

@admin.register(Heading)
class HeadingAdmin(admin.ModelAdmin):
    list_display = ['heading_name']

@admin.register(SpecialHeadng)
class SpecialHeadngAdmin(admin.ModelAdmin):
    list_display = ['name']

@admin.register(SpeacialHeadingProduct)
class SpeacialHeadingProductAdmin(admin.ModelAdmin):
    list_display = ['special_heading', 'id']

@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = ['mobile_number', 'product', 'quantity', 'price']

@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ['phone']

@admin.register(Payment)
class PaymentModelAdmin(admin.ModelAdmin):
    list_display = ['id','user','amount','razorpay_order_id','razorpay_payment_status','razorpay_payment_id','paid']

class OrderAdmin(admin.ModelAdmin):
    list_display = ('product', 'customer', 'quantity', 'price', 'total_discounted_price', 'address', 'phone', 'name', 'time', 'date', 'order_status', 'paid_status', 'Payment', 'user')

    def total_discounted_price(self, obj):

        discounted_price = obj.product.price - (obj.product.price * obj.product.offer_percent / 100) if obj.product.offer_percent else obj.product.price

        total_discounted_price = discounted_price * obj.quantity
        return round(total_discounted_price)

    total_discounted_price.short_description = 'Total Discounted Price'

admin.site.register(Order, OrderAdmin)

class UserAddressBookAdmin(admin.ModelAdmin):
    list_display = ['user', 'address', 'status']
admin.site.register(UserAddressBook,UserAddressBookAdmin)

@admin.register(PincodeAvailable)
class PincodeAdmin(admin.ModelAdmin):
    list_display = ['pincode']





    