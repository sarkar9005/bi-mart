
document.addEventListener('DOMContentLoaded', function () {
    // Slider buttons functionality
    let leftbtn = document.querySelector(".btn-l");
    let rightbtn = document.querySelector(".btn-r");
    let slider = document.querySelector(".slider-sec");

    if (rightbtn) {
        rightbtn.addEventListener('click', function (event) {
            let c = document.querySelector(".product-slide");
            c.scrollLeft += 1100;
            event.preventDefault();
        });
    }

    if (leftbtn) {
        leftbtn.addEventListener('click', function (event) {
            let c = document.querySelector(".product-slide");
            c.scrollLeft -= 1100;
            event.preventDefault();
        });
    }

    // Account box functionality
    const accountBtn = document.querySelector('.account_btn');
    const accountBox = document.querySelector('.account_box');

    if (accountBtn) {
        accountBtn.addEventListener('click', function (event) {
            event.preventDefault();
            accountBox.style.display = (accountBox.style.display === 'none' || accountBox.style.display === '') ? 'block' : 'none';
        });
    }

    // Hide cart notification if total count is zero
    const cartNotification = document.querySelector('.cart-button');
    if (cartNotification) {
        const totalCount = parseInt(cartNotification.querySelector('.total-count').innerText.split(' ')[0], 10);
        cartNotification.style.display = (totalCount === 0) ? 'none' : 'block';
    }

    // Handle add-to-cart forms
    document.querySelectorAll('form.add-to-cart-form').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            event.preventDefault();
    
            const formData = new FormData(form);
    
            fetch(form.action, {
                method: 'POST',
                body: formData,
            })
            .then(response => {
                // Check if the response is JSON
                const contentType = response.headers.get('content-type');
                if (contentType && contentType.includes('application/json')) {
                    return response.json();
                } else {
                    // Handle non-JSON responses
                    return response.text().then(text => {
                        throw new Error(`Unexpected response type: ${text}`);
                    });
                }
            })
            .then(data => {
                if (data.login_required) {
                    showLoginPopup();
                } else if (data.error) {
                    alert(data.error);  // Show the error in an alert (or handle it as you see fit)
                } else {
                    // Save the current scroll position
                    var scrollPosition = window.scrollY;
                    localStorage.setItem('scrollPosition', scrollPosition);
    
                    // Reload the page
                    location.reload();
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    });
    

    // Restore scroll position after page reload
    var savedScrollPosition = localStorage.getItem('scrollPosition');
    if (savedScrollPosition) {
        window.scrollTo(0, parseInt(savedScrollPosition));
        localStorage.removeItem('scrollPosition');
    }

    // Popup functionality
    let continueButton = document.querySelector('.continue_loig');
    let popupOverlay = document.querySelector('.popup-overlay');
    let closePopup = document.querySelector('.close-popup');

    if (continueButton && popupOverlay) {
        continueButton.addEventListener('click', function () {
            popupOverlay.style.display = 'flex'; // Show the popup
        });
    }

    if (closePopup && popupOverlay) {
        closePopup.addEventListener('click', function () {
            popupOverlay.style.display = 'none'; // Hide the popup
        });
    }

    if (popupOverlay) {
        popupOverlay.addEventListener('click', function (event) {
            if (event.target === popupOverlay) {
                popupOverlay.style.display = 'none'; // Hide the popup
            }
        });
    }

    // Trigger and close popup
    var trigger = document.getElementById('popup-trigger');
    var popup = document.getElementById('popup');
    var close = popup ? popup.querySelector('.close') : null;

    if (trigger) {
        trigger.addEventListener('click', function (event) {
            event.preventDefault();
            if (popup) {
                popup.style.display = 'block';
            }
        });
    }

    if (close) {
        close.addEventListener('click', function () {
            if (popup) {
                popup.style.display = 'none';
            }
        });
    }

    // Optional: Close the popup when clicking outside of it
    window.addEventListener('click', function (event) {
        if (popup && event.target === popup) {
            popup.style.display = 'none';
        }
    });
});
