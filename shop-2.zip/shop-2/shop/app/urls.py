from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from .views import home, CategoryView, SubcategoryView, ProductDetailView, AllCategoriesView

urlpatterns = [
    path('', home, name='home'),
    path('category/<int:val>/', CategoryView.as_view(), name='category'),
    path('subcategory/<int:val>/', SubcategoryView.as_view(), name='subcategory'),
    path('product/<int:pk>/', ProductDetailView.as_view(), name='product_detail'),
    path('allcategories/', AllCategoriesView.as_view(), name='all_categories'),
]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
