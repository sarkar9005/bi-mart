from django.shortcuts import render
from django.views import View
from django.shortcuts import get_object_or_404
from django.db.models import Count
from urllib import request
from .models import Product, Heading, Category, SpeacialHeadingProduct, SpecialHeadng, Subcategory, Brand


def home(request):
    headings = Heading.objects.all()
    special_heading_list = SpecialHeadng.objects.all()
    heading_category_map = {}
    special_heading_product_list = []
    category_subcategory_map = {}

    for heading in headings:
        categories = Category.objects.filter(heading=heading)
        heading_category_map[heading.heading_name] = categories
        for category in categories:
            subcategories = Subcategory.objects.filter(category=category)
            category_subcategory_map[category.category_name] = subcategories

    for special_heading in special_heading_list:
        product_list = []
        for special_product in SpeacialHeadingProduct.objects.filter(special_heading=special_heading.pk):
            product_list.append(special_product.product)
        special_heading_product_list.append({
            "name": special_heading.name,
            "description": special_heading.description,
            "product_list": product_list
        })

    products = Product.objects.all()

    categories = Category.objects.all()  

    context = {
        'heading_category_map': heading_category_map,
        'special_heading_product_list': special_heading_product_list,
        'category_subcategory_map': category_subcategory_map,
        'products': products,
        'categories': categories 
    }

    return render(request, "app/home.html", context)



class CategoryView(View):
    def get(self, request, val):
        category = get_object_or_404(Category, pk=val)
        subcategories = Subcategory.objects.filter(category=category)
        products = Product.objects.filter(category=category)
        for product in products:
            if product.units:
                product.unit_list = product.units.split(',')
        context = {
            'category': category,
            'subcategories': subcategories,
            'products': products,
        }
        return render(request, "app/category.html", context)


class SubcategoryView(View):
    def get(self, request, val):
        subcategory = get_object_or_404(Subcategory, pk=val)
        category = subcategory.category  
        subcategories = Subcategory.objects.filter(category=category)
        products = Product.objects.filter(subcategory=subcategory)
        brand_filter = request.GET.get('brand', None)
        
     
        
        brands = Brand.objects.filter(product__subcategory=subcategory).distinct()
        
        context = {
            'subcategory': subcategory,
            'category': category,
            'subcategories': subcategories,
            'products': products,
            'brands': brands,
            'brand_filter': brand_filter,
        }
        
        return render(request, "app/subcategory.html", context)



class ProductDetailView(View):
    def get(self, request, pk):
        product = get_object_or_404(Product, pk=pk)

        # Fetch brands associated with the product's category
        brands = Brand.objects.filter(product__category=product.category).distinct()
        
        # Fetch similar products
        similar_products = Product.objects.filter(category=product.category).exclude(pk=product.pk)[:10]
        
        context = {
            'product': product,
            'brands': brands,
            'similar_products': similar_products  
        }
        return render(request, "app/product_detail.html", context)

class AllCategoriesView(View):
    def get(self, request):
        categories = Category.objects.prefetch_related('subcategory_set').all()
        selected_category = None
        subcategories = []
        products = []

        if categories:
            selected_category_id = request.GET.get('category_id')
            if selected_category_id:
                selected_category = get_object_or_404(Category, pk=selected_category_id)
            else:
                selected_category = categories.first()

            subcategories = Subcategory.objects.filter(category=selected_category)
            products = Product.objects.filter(category=selected_category)
    

        context = {
            'categories': categories,
            'selected_category': selected_category,
            'subcategories': subcategories,
            'products': products,
        }
        return render(request, "app/all_categories.html", context)





   
