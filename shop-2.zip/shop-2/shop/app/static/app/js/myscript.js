let leftbtn =document.querySelector(".btn-r");
let rightbtn =document.querySelector(".btn-l");
let slider = document.querySelector("slider-sec")

rightbtn.addEventListener('click',function(event){
    let c =document.querySelector(".product-slide");
    c.scrollLeft += 1100;
    event.preventDefault();
})
leftbtn.addEventListener('click',function(event){
    let c =document.querySelector(".product-slide");
    c.scrollLeft -= 1100;
    event.preventDefault();
})

let list_price = document.querySelector('.rate').innerHTML
let selling_price = document.querySelector('.c-rate').innerHTML
let offer_pr = document.querySelector('.offer') 


document.addEventListener('DOMContentLoaded', function() {
    const addToCartButtons = document.querySelectorAll('.add-cart-btn');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const unitSelect = document.querySelector(`#unit-select-${productId}`);
            const unit = unitSelect ? unitSelect.value : '';

            fetch(`/add_to_cart/${productId}/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify({ unit: unit })
            }).then(response => response.json())
              .then(data => {
                  if (data.message === 'Added to cart') {
                      // Hide add to cart button and show plus, minus, and cart count buttons
                      this.style.display = 'none';
                      const cartControls = document.querySelector(`#cart-controls-${productId}`);
                      cartControls.style.display = 'block';
                  }
              });
        });
    });

    const cartControlButtons = document.querySelectorAll('.cart-control-btn');
    cartControlButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const unit = this.dataset.unit;
            const action = this.dataset.action;

            fetch(`/update_cart/${productId}/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify({ unit: unit, action: action })
            }).then(response => response.json())
              .then(data => {
                  if (data.quantity === 0) {
                      // Show add to cart button and hide cart controls
                      const addToCartButton = document.querySelector(`#add-cart-btn-${productId}`);
                      addToCartButton.style.display = 'block';
                      const cartControls = document.querySelector(`#cart-controls-${productId}`);
                      cartControls.style.display = 'none';
                  } else {
                      const cartCount = document.querySelector(`#cart-count-${productId}`);
                      cartCount.textContent = data.quantity;
                  }
              });
        });
    });
});

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

