from django.contrib import admin
from . models import Product, Heading, Category, Subcategory, SpeacialHeadingProduct, SpecialHeadng, Brand
# Register your models here.

@admin.register(Product)
class Admin(admin.ModelAdmin):
    list_display = ['name', 'id', 'desc',  'price', 'offer_percent', 'image1', 'image2', 'image3', 'image4', 'image5', 'que','subcategory',]
    
@admin.register(Category)
class Admin(admin.ModelAdmin):
    list_display = ["category_name"]

@admin.register(Subcategory)
class Admin(admin.ModelAdmin):
    list_display = ['sub_category_name']

@admin.register(Brand)
class Admin(admin.ModelAdmin):
    list_display = ['name']


@admin.register(Heading)
class Admin(admin.ModelAdmin):
    list_display = ['heading_name']

@admin.register(SpecialHeadng)
class Admin(admin.ModelAdmin):
    list_display = ['name']

@admin.register(SpeacialHeadingProduct)
class Admin(admin.ModelAdmin):
    list_display = ['special_heading', 'id', ]